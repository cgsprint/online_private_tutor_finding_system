export const ADMIN_BASE_URL = `http://localhost:8080/admin`;
export const TUTOR_BASE_URL = `http://localhost:8080`;
export const PARENT_BASE_URL = `http://localhost:8080/parent`;
