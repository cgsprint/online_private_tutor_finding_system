import React from 'react'

function TutorHome() {
    return (
        <div>
            <h2>Hello Tutor</h2>

            <hr></hr>
<footer class="text-muted">
  <div class="container">
        <small class="d-block mb-3 text-muted">&copy; 2021 Online Private Tutor Finder System</small>
    <p class="float-right">
      <a href="#">Back to top</a>
    </p>
  </div>
  </footer><hr></hr>
        </div>
    )
}

export default TutorHome
