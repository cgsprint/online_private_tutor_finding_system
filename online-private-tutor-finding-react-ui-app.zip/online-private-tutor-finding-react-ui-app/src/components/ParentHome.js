import React from 'react'

function ParentHome() {
    return (
        <div>
            <h2>Hello Parent</h2>

            <hr></hr>
<footer class="text-muted">
  <div class="container">
        <small class="d-block mb-3 text-muted">&copy; 2021 Online Private Tutor Finder System</small>
    <p class="float-right">
      <a href="#">Back to top</a>
    </p>
  </div>
  </footer><hr></hr>
        </div>
    )
}

export default ParentHome
