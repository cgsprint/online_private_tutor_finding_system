import React, { Component } from 'react';
import axios from 'axios'
import * as actionCreated from '../actions/TutorActions'
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';


class TutorViewEbook extends Component {

    constructor(props) {
        super(props)
    
       
    }       
    
    componentDidMount() {
        this.props.onViewEbooks()
    }

   

    render() {

        let ebooklist= this.props.ebooklist.map((ebook , index) => {
            return(
                <tr key={index}>
                <th>{ebook.ebookId}</th>
                <td>{ebook.title}</td>
                <td>{ebook.author}</td>
                <td>{ebook.url}</td>
                
                </tr>
                )
            })
        return (
            <div>
                <table className="table table-info demo-request-table">
                    <thead>
                        <tr>
                            <th scope="col">EbookId</th>
                            <th scope="col">Title</th>
                            <th scope="col">Author</th>
                             <th scope="col">Url</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                           ebooklist
                        }
                    </tbody>
                </table>
                <hr></hr>
<footer class="text-muted">
  <div class="container">
        <small class="d-block mb-3 text-muted">&copy; 2021 Online Private Tutor Finder System</small>
    <p class="float-right">
      <a href="#">Back to top</a>
    </p>
  </div>
  </footer><hr></hr>
            </div>
        )
    }
        
        
    
}




const mapStateToProps = (state) => {
    return {
        returnedMessage: state.returnedMessage
    }
  }
  
  const mapDispatchToProps = (dispatch) => {
    return {  
        onViewEbooks: () => {
            return dispatch(actionCreated.getAllEbooks())
          },
          clearState: () => {
            return  dispatch(actionCreated.clearState())
  
          }
    }
  
  }
  


  export default connect(mapStateToProps, mapDispatchToProps)(withRouter(TutorViewEbook))
  
