import React, { Component } from 'react';

class ViewEbook extends Component {
        
    render() {
        return (
            <div>

                <h2 className="text-center">Ebook List</h2>

                <table className="table table-stripped">
                    <thead>
                        <tr>
                            <th scope="col">Id</th>
                            <th scope="col">Title</th>
                            <th scope="col">Authorname</th>
                            <th scope="col">Url</th>
                        </tr>
                    </thead>

                </table>

                <hr></hr>
<footer class="text-muted">
  <div class="container">
        <small class="d-block mb-3 text-muted">&copy; 2021 Online Private Tutor Finder System</small>
    <p class="float-right">
      <a href="#">Back to top</a>
    </p>
  </div>
  </footer><hr></hr>
            </div>
        );
    }
}

export default ViewEbook;