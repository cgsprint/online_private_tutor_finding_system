import React, { Component } from 'react'

export class ParentLoginRegister extends Component {
    render() {
        return (
            <div>
                
            </div>
        )
    }
}

export default ParentLoginRegister
